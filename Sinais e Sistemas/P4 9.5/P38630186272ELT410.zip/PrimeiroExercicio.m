%%%% 1.1  Exerc�cio 1: Resposta ao impulso %%%%
% Resposta ao impulso unit�rio. 
clc; clear; close all;
n = 0:19; % Intervalo de an�lise.
x = @(n) n==0; % Fun��o impulso unit�rio.
a = [1 -0.6 -0.16]; % Coeficientes de y[n].
b = [5 0 0 ]; % Coeficiente de x[n].
h = filter(b,a,x(n)); % Resposta � entrada x[n].
subplot(3,2,1)
stem(n,x(n),'k','LineWidth',2)
xlabel('Tempo discreto (n)');  ylabel('x_[_n_]'); title('Entrada do Sistema');
subplot(3,2,2)
stem(n,h,'k','LineWidth',2) % Plota o gr�fico da resposta.
xlabel('Tempo (n)');  ylabel('y_[_n_]'); title('Resposta para o impulso unit�rio');

% Resposta ao degrau unit�rio.
x = @(n) n>=0; % Fun��o degrau unit�rio.
h = filter(b,a,x(n)); % Resposta � entrada x[n].
subplot(3,2,3)
stem(n,x(n),'k','LineWidth',2)
xlabel('Tempo discreto (n)');  ylabel('x_[_n_]'); title('Entrada do Sistema');
subplot(3,2,4)
stem(n,h,'k','LineWidth',2) % Plota o gr�fico da resposta.
xlabel('Tempo (n)');  ylabel('y_[_n_]'); title('Resposta para o degrau unit�rio');

% Resposta � fun��o Sinc.
x = @(n)sin(n)./n; % Fun��o sinc.
n = n + eps; % Incremento infinitesimal na vari�vel independente.
h = filter(b,a,x(n)); % Resposta � entrada x[n].
subplot(3,2,5)
stem(n,x(n),'k','LineWidth',2)
xlabel('Tempo discreto (n)');  ylabel('x_[_n_]'); title('Entrada do Sistema');
subplot(3,2,6)
stem(n,h,'k','LineWidth',2)  % Plota o gr�fico da resposta.
xlabel('Tempo (n)');  ylabel('y_[_n_]'); title('Resposta para Fun��o sinc');

