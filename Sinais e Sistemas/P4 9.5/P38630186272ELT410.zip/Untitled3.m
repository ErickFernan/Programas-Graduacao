%%%% 1.3 Exerc�cio 3: Implementa��o da convolu��o discreta bidimensional %%%%
clc; clear; close all
load ('lua 08092019155226.jpg'); % Carrega a imagem "lua.jpg".
I = imread('lua 08092019155226.jpg'); % L� a imagem.
figure (1) 
subplot(3,2,1); imshow(I, [0 255]); title('Imagem Original'); % Exibe a imagem.
F = [-1 -1 -1;-1 8 -1;-1 -1 -1]; % Sistema descrito por um filtro de Laplace de terceira ordem.
y = convolucao2D(F, I); % Real�a os detalhes da imagem convoluindo-a com o filtro F.
subplot(3,2,2); imshow(y, [0 255]); title('Imagem Filtrada 1'); % Exibe a imagem com detalhes real�ados.
If = uint8( double(I) + imresize(convolucao2D(F,I),size(I))); % Converte o sinal para 8 bits.
subplot(3,2,3); imshow(If, [0 255]); title('Imagem Filtrada 2');% Exibe imagem real�ada com maior qualidade.

F1 = 1/9 * ones(3); % Filtro passa-baixas.
z = convolucao2D(F1, I); % Convolu��o do filtro com a imagem (filtra a imagem).
subplot(3,2,4); imshow(z, [0 255]); title('Imagem Filtrada 3');
If = uint8( double(I) + imresize(convolucao2D(F1,I),size(I))); % Converte o sinal para 8 bits.
subplot(3,2,5); imshow(If, [0 255]); title('Imagem Filtrada 4');% Exibe imagem filtrada com maior qualidade.

F4 = [-1 -1 0; -1 3 0; 0 0 0];
z0 = convolucao2D(F4, I); % Convolu��o do filtro com a imagem (filtra a imagem).
subplot(3,2,6); imshow(z0, [0 255]); title('Imagem Filtrada 5');

load ('texto 08092019155244.jpg');
T = imread('texto 08092019155244.jpg'); % L� a imagem.
figure (2)
subplot(1,2,1); imshow(T, [0 255]); 
z1 = conv2 (F1, T); % Convolu��o do filtro com a imagem (melhora a qualidade).
If = uint8(imresize(conv2(F1,T),size(T)));
subplot(1,2,2); imshow(If, [0 255]); 
