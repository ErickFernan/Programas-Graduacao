%%%% 1.2  Exerc�cio 2: Implementa��o da convolu��o discreta %%%%

function [result] = convolucao(x,h)
N = length(x); % Extrai o n�mero de termos de x. 
M = length(h); % Extrai o n�mero de termos de y.
tamY = length(x) + length(h) - 1; % Comprimento do vetor resultado da convolu��o.
result = zeros(1, tamY); % Vetor onde ser� armazenado o resultado da convolu��o.
x = [x zeros(1, N+M)]; % Adiciona elementos nulos em x.
for i = 0:tamY % Itera sobre o n�mero de termos da convolu��o.  
    for j = 1:M % Convolu��o.
        if i-j > -1 % Somat�rio caracter�stico.
            y(i) = h(j).*x(i-j+1);
            result(i) = result(i) + y(i); % Soma os valores de cada termo. 
        end
    end
end
% disp('Convolu��o: '); disp(result);
end


