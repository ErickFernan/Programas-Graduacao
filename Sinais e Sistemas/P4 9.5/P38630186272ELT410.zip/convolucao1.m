%%%% 1.2  Exerc�cio 2: Implementa��o da convolu��o discreta %%%%
function[result] = convolucao1(x,h)
k = size(h, 2); % N�mero de colunas de h.
n = k + 1; 
for k = k:-1:1
    hk(n-k) = h(k); % Inverte o vetor h.
end
xk = [zeros(1,size(h, 2)-1) x zeros(1,size(h, 2)-1)]; % Completa a matriz com zeros.
for t = 1:size(xk, 2) - size(hk,2) + 1
    result(t) = sum(hk.*xk(t:t + size(hk,2)-1)); % Realiza a soma de convolu��o.
end 
% disp('Convolu��o: '); disp(result);
end 




