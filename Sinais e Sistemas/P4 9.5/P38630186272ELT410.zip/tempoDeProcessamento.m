%%%% Verifica o tempo de processamento da fun��o implementada e compara com
%%%% o tempo de processamento do comando conv %%%%

clc; clear; close all
x = [1 2 5 6] % Vetores a serem convolu�dos.
h = [2 5 4 5]

tic;
convolucao(x,h);
averageTime0 = toc;
disp('Convulu��o implementada 1: '); disp(convolucao(x,h));
disp('Tempo de processamento: '); disp(averageTime0);

tic;
convolucao1(x,h);
averageTime1 = toc;
disp('Convulu��o implementada 2: '); disp(convolucao1(x,h));
disp('Tempo de processamento: '); disp(averageTime1);

tic;
conv(x,h);
averageTime2 = toc;
disp('Convulu��o MATLAB: '); disp(conv(x,h));
disp('Tempo de processamento: '); disp(averageTime2);

figure (1)
hold on

title('Fun��es convolu��o');
xlabel('Fun��es de convolu��o');
ylabel('Tempo de resposta em segundos');
title('Fun��es convolu��o');
grid on
plot(1,averageTime0,'ok','LineWidth',2);
plot(2,averageTime1,'or','LineWidth',2);
plot(3,averageTime2,'og','LineWidth',2);



