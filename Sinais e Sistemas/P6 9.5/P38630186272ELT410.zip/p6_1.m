%% UNIVERSIDADE FEDERAL DE VI�OSA
%  ELT - 410 SINAIS E SISTEMAS
%  ERICK AMORIM FERNANDES 86301
%  MAYELLI COSTA FERREIRA 86272

clc;
close all;
clear all;

%% Roteiro 6 - Parte 1 - Fen�meno de Gibbs

k     = 10;
Ak    = [-k:1:k];
coef  = ak(Ak);
Abs   = abs(coef);
Angle = angle(coef);

subplot(2,1,1);
stem(Ak,Abs,'linewidth',2);
title('M�dulo de ak');
subplot(2,1,2);
stem(Ak,Angle,'linewidth',2);
title('Fase de ak');

%% Trigonom�trica compacta

hold on
k     = 30;
Ak    = [-k:1:k];
coef  = ak(Ak);
Abs   = abs(coef);
Angle = angle(coef);
t  = -10:.01:10;
an=0;
for j=1:k
  an=an+(2*abs(coef(k+1+j))*cos(j*2*pi*0.25.*t+angle(coef(k+1+j))));
end
x = 1+2*an;

plot(t,x,'g','linewidth',2);
title('Representa��o da onda quadrada para s�rie de Fourier com kmax=[5 10 30]')
ylabel('x(t)')
xlabel('t')
%% Minimiza��o do efeito Gibbs

u=linspace(-10,10,10000);
sq=[zeros(1,500),2*ones(1,1000),zeros(1,1000),2*ones(1,1000),zeros(1,1000),...
2*ones(1,1000), zeros(1,1000),2*ones(1,1000), zeros(1,1000),2*ones(1,1000),...
zeros(1,500)];
plot(u,sq,'--r','linewidth',2)
xlabel('t')
ylabel('x(t)')
axis([-10 10 -0.5 2.5])
title('Onda quadrada')
grid on

%% Janelamento Fej�r
hold on
k     = 100;
Ak    = [-k:1:k];
coef  = ak(Ak);
Abs   = abs(coef);
Angle = angle(coef);
t  = -10:.01:10;
an=0;
wk=0;
for j=1:k
  wk= (k-j)/k;
  an=an+((2*abs(coef(k+1+j))*cos(j*2*pi*0.25.*t+angle(coef(k+1+j)))))*wk;
end
x = 1+2*an;

plot(t,x,'b','linewidth',2);


%% Aproxima��o sigma
hold on
k     = 25;
Ak    = [-k:1:k];
coef  = ak(Ak);
Abs   = abs(coef);
Angle = angle(coef);
t  = -10:.01:10;
an=0;
wk=0;
for j=1:k
  wk= sinc(j/k);
  an=an+((2*abs(coef(k+1+j))*cos(j*2*pi*0.25.*t+angle(coef(k+1+j)))))*wk;
end
x = 1+2*an;

plot(t,x,'b','linewidth',2);
