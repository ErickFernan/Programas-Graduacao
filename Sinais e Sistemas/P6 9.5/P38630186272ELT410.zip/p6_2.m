%% UNIVERSIDADE FEDERAL DE VI�OSA
%  ELT - 410 SINAIS E SISTEMAS
%  ERICK AMORIM FERNANDES 86301
%  MAYELLI COSTA FERREIRA 86272

clc;
close all;
clear all;

%% Roteiro 6 - Parte 2 - Sintetizador de som
%% 1
load ('trumpet.mat');
plot(trumpet);
sound(trumpet);
%% 2
t1 = trumpet(1:11025);
t2 = trumpet(11026:22050);
t3 = trumpet(22051:33075);
%% 3
figure
plot(t1)
title('Trecho 1')
figure
plot(t2)
title('Trecho 2')
figure
plot(t3)
title('Trecho 3')

%% 4
Fs = 11025;
Y = fft(trumpet,512);
Ymag = abs(Y(1:257));
Yfas = angle(Y(1:257));
f = Fs*(0:256)/512;
subplot(2,1,1),plot(f, Ymag);
xlabel('Frequ�ncia (Hz)');
ylabel('M�dulo');
subplot(2,1,2),plot(f, Yfas);
xlabel('Frequ�ncia (Hz)');
ylabel('Fase');
%% 5
[mag, id]    = sort(Ymag, 'descend'); % Pega a magnitude do vetor onde � maxima. id = onde as posi��es s�o m�ximas
mag = mag';      % Transp�e o vetor.
fas = Yfas(id)'; % Pega as posi��es onde as fase s�o m�ximas, que coincide com o vetor id.
freq = f(id);    % Pega as frequ�ncias onde os valores s�o m�ximos
t   = 0:1/Fs:1;  % Tempo de amostragem.
%% 6 Fun��o que recebe vetor de tempo(t), frequ�ncia(freq) e m�dulo(mag);
sint = somacosseno(t,freq,mag); %sint = som sintetizado;
subplot(3,1,1)
plot(sint);
title('Maior picos')
sound(sint);

%% 7 PLotar por��es dos sinais unsado subplot
%% 8 mais e menos harm�nicos
%% Somacosseno2
fas =[1 1 1 1 1];
sint = somacosseno2(t,freq,mag,fas); %sint = som sintetizado;
subplot(2,1,1)
plot(sint);
title('Valores unit�rios')
sound(sint);








