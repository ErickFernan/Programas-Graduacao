function [x1] = somacosseno(t,freq,mag)
% Inicia o vetor x com zeros
x1 = zeros(1,length(t));
for n = 1:1
x1 = x1 + 2*mag(n)*cos(2*pi*freq(n)*t);
end
%Normalizando a sa�da
x1 = x1/max(abs(x1));
end