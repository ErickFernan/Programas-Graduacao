function [x1] = somacosseno2(t,freq,mag,fas)
% Inicia o vetor x com zeros
x1 = zeros(1,length(t));
for n = 1:5
x1 = x1 + 2*mag(n)*cos(2*pi*freq(n)*t+fas(n));
end
%Normalizando a sa�da
x1 = x1/max(abs(x1));
end