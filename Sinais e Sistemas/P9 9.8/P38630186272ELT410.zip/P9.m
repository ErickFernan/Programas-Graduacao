clc;
close all;
clear all;

%% Pr�tica 9

fs = 1000;
t = 0:1/fs:3;
f0 = 150;
t1 = 3;
f1 = 450;
B = (f1-f0)/t1;
y = cos(2*pi*(f0*t+B/2*t.^2));
Y = abs(fft(y));
subplot(1,2,2);
plot(y);
title('y(t)');
xlabel('Tempo (s)')
ylabel('Amplitude')
F = linspace(0,fs/2,round(length(y)/2));
subplot(1,2,1);
plot(F,Y(1:round(length(y)/2)));
title('Espectro de y(t)');
xlabel('Frequencia (Hz)')
ylabel('Magnitude')

[S,F,T] = espectrograma(y,256,20,256,fs);
figure
subplot(1,2,1);
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');

[S,F,T] = espectrograma(y,256,20,256,fs);
subplot(1,2,2);
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');
zlabel('Intensidade');
axis xyz; axis tight; view(0,90);



%% Lena fig 4

A = audioread('lena.wav');
%sound(A);
[S,F,T] = espectrograma(A,1024,100,1024,fs);
figure
subplot(1,2,1)
colormap(gray)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');
subplot(1,2,2)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');
zlabel('Intensidade');

axis xyz; axis tight; view(0,90);

%% Lena fig 5

A = audioread('lena.wav');
%sound(A);
[S,F,T] = espectrograma(A,512,200,512,fs);
figure
subplot(1,2,1)
colormap(gray)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');
[S,F,T] = espectrograma(A,128,100,1024,fs);
subplot(1,2,2)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');
zlabel('Intensidade');
axis xy; axis tight; view(0,90);

%%

[B,Fs] = audioread('02AphexTwin.wav');
[S,F,T] = espectrograma(B,1024,0,1024,Fs);
figure
subplot(2,1,2)
colormap(gray)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');
axis([326 338 0 22050 ])


[B2,Fs2] = audioread('VenetianSnaresLook.wav');
% sound(B);
[S,F,T] = espectrograma(B2,1024,0,1024,Fs2);
subplot(2,1,1)
colormap(gray)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');

%%

[B2,Fs2] = audioread('Coagula.wav');
% sound(B);
[S,F,T] = espectrograma(B2,512,0,2000,Fs2);
figure
colormap(gray)
surf(T,F,10*log10(abs(S)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Tempo (s)');
ylabel('Frequencia (Hz)');

%% 4 Canto das baleias 

load whalecalls.mat

% Escutar cada linha do som:
for i = 1:length(X1(:,1)) 
    %sound(X1(i,:), fs)
    %pause(5)
end

% espectrograma de cada �udio:
for i = 1:length(X1(:,1))
    [S,Fs,T] = espectrograma(X1(i,:),256,20,256,fs);
    figure
    surf(T,Fs,10*log10(abs(S)),'EdgeColor','none'); 
    %colormap(gray) % Espectrogramma em tons de cinza
    axis xy; axis tight; view(0,90); 
    xlabel('Tempo (s)'); ylabel('Frequencia (Hz)'); zlabel('Intensidade');
end
%% 

for i = 1:length(X2(:,1)) 
    %sound(X2(i,:), fs)
    %pause(5)
end
% espectrograma de cada �udio:
for i = 1:length(X2(:,1))
    [S,Fs,T] = espectrograma(X2(i,:),256,20,256,fs);
    figure
    surf(T,Fs,10*log10(abs(S)),'EdgeColor','none'); 
    %colormap(gray) % Espectrogramma em tons de cinza
    axis xy; axis tight; view(0,90);
    xlabel('Tempo (s)'); ylabel('Frequencia (Hz)'); zlabel('Intensidade');
end